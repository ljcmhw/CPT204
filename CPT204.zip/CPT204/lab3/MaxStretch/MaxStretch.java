import java.util.Arrays;
import java.util.List;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;

public class MaxStretch {

    /**
     * Find the largest stretch in a list.
     * For example, maxStretch([8, 5, 1, 2, 3, 4, 5, 10]) = 6.
     * @param list is a list of integers.
     * @return the largest stretch in list.
     */
    public static int maxStretch(List<Integer> list) {
        int max = 0;
        int judge = 0;
        for (int x : list){
            if(list.indexOf(x)==list.lastIndexOf(x)){
                judge=1;

            }
            else {
                judge=list.lastIndexOf(x)- list.indexOf(x)+1;

            }
            if(judge>max){
                max=judge;
            }
        }
		
		
        return max;
    }
}