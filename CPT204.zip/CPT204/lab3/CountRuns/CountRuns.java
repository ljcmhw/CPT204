import java.util.*;

public class CountRuns {

    /**
     * Count the number of runs in a list.
     * For example, countRuns([1, 2, 2, 2, 3]) = 1.
     * @param list is a list of integers.
     * @return the number of runs in list.
     */
    public static int countRuns(List<Integer> list) {
        int runs = 0;
        int index = 0;
        int level = 0;//防止多个相同元素连续出现导致runs被累加
        for(int x : list){

//            for(int count=1; count<list.size()-index;count++){
//                if (x!=list.get(index+count)){
//                    level=count;
//                    break;
//                }
//            }
//
//        if((level!=1)){
//            if(index!=0){
//                if(list.get(index)!=(list.get(index-1))){
//                    runs++;
//                }
//            }else {
//                runs++;
//
//            }
//
//        }
        if(index!=0){
        if(x==list.get(index-1)&&level==0){
            runs++;
            level=1;
        }
        if(x!=list.get(index-1)&&level!=0){
            level=0;
        }}
        index++;
        }
		
		
        return runs;
    }
    public static void main(String[] args){
        List<Integer>list= Arrays.asList(1,2,2,2,4,3,3);
        int result;
        //int x;
        //x=list.get(1);
        result=countRuns(list);
        System.out.println(result);
        //System.out.println(list.get(list.indexOf(x)+1)==x);
    }
}

