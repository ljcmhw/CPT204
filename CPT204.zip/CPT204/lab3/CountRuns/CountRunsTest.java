import java.util.Arrays;
import java.util.List;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import org.junit.Test;
import static org.junit.Assert.*;

public class CountRunsTest {

    @Test
	// add test cases
	public void testCountRuns(){
        List<Integer>list=Arrays.asList(1,2,2,2,2,3);
        assertEquals(1,CountRuns.countRuns(list));

    }
	
	
}