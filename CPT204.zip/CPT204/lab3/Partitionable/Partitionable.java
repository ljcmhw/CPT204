import java.util.List;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;

public class Partitionable {

    /**
     * Decide whether a list is partitionable.
     * For example, isPartitionable([1, 1, 1, 2, 1]) -> true,
     * and isPartitionable([2, 1, 1, 2, 1]) -> false.
     * @param list is a non-empty list of integers.
     * @return true iff list is partitionable.
     */
    public static boolean isPartitionable(List<Integer> list) {
        boolean judge=false;
        int sum1=0,sum2=0;
        for (int index=0; index<list.size();index++){
            for(int index1=0; index1<=index;index1++){
                sum1+=list.get(index1);
            }
            for(int index2=list.size()-1; index2>index;index2--){
                sum2+=list.get(index2);
            }
            if(sum1==sum2){
                judge=true;
                break;
            }
            if(sum1!=sum2){
                sum1=0;
                sum2=0;
            }
        }
		
		
        return judge;
    }
}