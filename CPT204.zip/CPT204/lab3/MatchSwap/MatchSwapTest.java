import org.junit.Test;
import static org.junit.Assert.*;
import java.util.Arrays;
import java.util.List;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;


public class MatchSwapTest {
	@Test
    public void testMatchSwap(){
        List<String>list=Arrays.asList("apple","avocado");
        List<String>list2=Arrays.asList("avocado","apple");
        assertTrue(list2.equals(MatchSwap.matchSwap(list)));

    }
    
	
	
	
}