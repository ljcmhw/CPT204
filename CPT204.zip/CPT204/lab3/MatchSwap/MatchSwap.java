import java.util.*;

public class MatchSwap {

    /**
     * Modify a list of strings such that two strings with same
     * first letter are swapped.
     * For example, matchSwap(["ap", "bp", "cp", "aq", "cq", "bq"]) →
     * ["aq", "bq", "cq", "ap", "cp", "bp"].
     * @param list is a list of strings.
     * The strings are non-empty.
     * @return the modified list.
     */
    public static List<String> matchSwap(List<String> list) {
        int index;
        String inter;
        List<String>list1=new ArrayList<>(list);

        for(String x:list){
            index=list.indexOf(x);

            for(int y=index+1;y<list.size();y++){

                if(x.substring(0,1).equals(list.get(y).substring(0,1))&&list1.indexOf(x)==index){
                    inter=x;
                    x=list.get(y);
                    list.set(index,x);
                    list.set(y,inter);
                    break;
                }
            }


        }
		
		
		
		return list;
    }


    public static void main(String[] args){
        List<String>listmain= Arrays.asList("ab","ac","ad","ae","af");
        List<String>listmain2=new ArrayList<>();
        listmain2=MatchSwap.matchSwap(listmain);
        System.out.println(listmain2);
    }

}

