package ataxx;

// Optional Task: The GUI for the Ataxx Game
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.ArrayList;


import static ataxx.PieceState.BLUE;
import static ataxx.PieceState.EMPTY;

class GUI implements View, CommandSource, Reporter {
    private JFrame window;
    private Board board=new Board();
    private JPanel panel=new JPanel();

    public void setBoard(Board b){
        board = b;
    }
    // Complete the codes here
    GUI(String ataxx) {
        window = new JFrame();
        window.setTitle(ataxx);
        window.getContentPane().setBackground(Color.CYAN);
        window.setSize(700,700);
        //window.setResizable(false);
        window.setLayout(null);
        update(board);
        Button b = new Button("Block");
        b.addActionListener(new MyActionListener());
        b.setActionCommand("block");
        b.setBounds(50,50,50,50);
        window.add(b);
    }

    // Add some codes here

    public void creatPanel(){
        panel = new JPanel();
        panel.setLayout(new GridLayout(Move.ONESIDE,Move.ONESIDE));
        panel.setBounds(100,100,500,500);
        for(char i='7';i>='1';i--){
            for(char j='a'; j<='g'; j++) {
                JButton b =new JButton();
                b.setOpaque(true);//设置默认颜色为透明
                //Border originBorder=BorderFactory.createLineBorder(Color.LIGHT_GRAY, 1);//更改mac里面默认的board类型，避免初始的board遮挡其它图层
                if(board.getContent(j,i).toString().equals("Red")){
                    b.setBackground(Color.RED);
//                    b.setForeground(Color.RED);
//                    b.setBorder(originBorder);
                }else if(board.getContent(j,i).toString().equals("Blue")){
                    b.setBackground(Color.BLUE);
//                    b.setForeground(Color.BLUE);
                } else if (board.getContent(j,i).toString().equals("Empty")) {
                    b.setBackground(Color.WHITE);
//                    b.setForeground(Color.WHITE);
                }else {
//                    b.setBackground(Color.GRAY);
//                    b.setForeground(Color.GRAY);
                    b.setBorderPainted(false);
                }
                b.setSize(50,50);
                b.setActionCommand(String.valueOf(j)+i);

                b.addActionListener(new MyActionListener());
                panel.add(b);
            }
        }
    }


    // These methods could be modified
	
    @Override
    public void update(Board board) {
        this.board = board;
        System.out.println(board.toString());
        window.remove(panel);
        creatPanel();
        window.add(panel);
        window.setVisible(true);

        window.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                System.exit(0);
            }
        });
    }

    @Override
    public String getCommand(String prompt) {

        if(action[0]!=null&&action[0].equals("new")){
            String s=action[0];
            action[0]=null;
            return s;
        }
        if(action[1]!=null)
            return iniAction();
        return "";
    }

    @Override
    public void announceWinner(PieceState state) {
            if(state!=EMPTY){
                JFrame winner = new JFrame();
                winner.setLayout(new FlowLayout());
                winner.setBackground(Color.BLUE);
                winner.setBounds(300,300,200,100);

                JLabel win = new JLabel("Winner is "+state.toString());
                win.setBounds(20,20,100,30);

                winner.add(win);

                Button b = new Button();
                b.setLabel("restart");
                b.addActionListener(new MyActionListener());
                b.setActionCommand("new");
                b.setBounds(20,50,100,30);


                winner.add(b);
                winner.setVisible(true);
            }
    }

    @Override
    public void announceMove(Move move, PieceState player) {

    }

    @Override
    public void message(String format, Object... args) {

    }

    @Override
    public void error(String format, Object... args) {

    }

    public void setVisible(boolean b) {
        window.setVisible(b);
    }

    public void pack() {
		//window.pack();
    }

    static String[] action = new String[2];

    static String getAction() {
        return action[0]+action[1];
    }

    static void setAction(String s) {
        if(action[0]==null){
            action[0]=s;
        }else{
            action[1]=s;
        }

    }
    static String iniAction(){

        String s = getAction();
        action = new String[2];
        return s;
    }
     class MyActionListener implements ActionListener{


        @Override
        public void actionPerformed(ActionEvent e) {
            if(e.getActionCommand().equals("new")){
                action[0]="new";
                return;
            }
            if(action[0]==null){
                setAction(e.getActionCommand());
            }else if(action[0].equals("block")){
                setAction(" "+e.getActionCommand());
            }
            else{
                setAction("-"+e.getActionCommand());
            }
            System.out.println(getAction());

        }
    }

}