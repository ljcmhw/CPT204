package ataxx;

import java.util.ArrayList;
import java.util.Random;

import static ataxx.PieceState.BLUE;
import static ataxx.PieceState.RED;
import static java.lang.Math.max;
import static java.lang.Math.min;

// Final Project Part A.2 Ataxx AI Player (A group project)

/** A Player that computes its own moves. */
class AIPlayer extends Player {

    //    set the max study depth for ai
    private static final int MAX_DEPTH = 4;
    //      private static final int MAX_DEPTH = 3;
    private static final int WINNING_VALUE = Integer.MAX_VALUE - 20;
    private static final int INFTY = Integer.MAX_VALUE;
    /** A new AIPlayer for GAME that will play MYCOLOR.
     *  SEED is used to initialize a random-number generator,
     *  increase the value of SEED would make the AIPlayer move automatically.
     *  Identical seeds produce identical behaviour. */
    AIPlayer(Game game, PieceState myColor, long seed) {
        super(game, myColor);
        Random _random = new Random(seed);
    }

    @Override
    boolean isAuto() {
        return true;
    }

    @Override
    String getAtaxxMove() {
        Move move = findMove();
        getAtaxxGame().reportMove(move, getMyState());
        return move.toString();
    }
    /** Find the movement from the BOARD position and return its score,
     * Record Moves found in _foundMove iff save is true.
     * If sense == 1, should have maximum value or have value > beta,
     * If sense == -1, then min or value < alpha.
     * Search up to Depth levels. Searching at depth == 0 returns only a static estimate
     * and do not set _foundMove. if game over On BOARD, do not set _foundMove
     *
     * @param board: A new board for ataxx,
     *        depth: Maximum minimax search depth before going to static evaluation
     *        save: Determine if this step should be stored
     *        sense =1, -1
     *        alpha , beta : Winning weight
     * @return The best score that can be obtained by the movement of current position  */
    private int minMax(Board board, int depth, boolean save, int sense, int alpha, int beta){
        if (depth == 0 || board.getWinner() != null){
            return staticScore(board,WINNING_VALUE+depth);
        }
        Move bestMove = null;

        int bestScore = 0;
        ArrayList<Move> allPossibleMoves;
        if (sense == 1){
//            if (board.moveLegal(Move.pass())){
//                allPossibleMoves.add(Move.pass());
//            }else{
            bestScore = -INFTY;
            allPossibleMoves = possibleMoves(board, RED);
            for (Move possible : allPossibleMoves){
                Board copy = new Board(board);
                copy.createMove(possible);
                int response = minMax(copy, depth - 1, false,-1,alpha,beta);
                if (response > bestScore){
                    bestMove = possible;
                    bestScore = response;
                    alpha = max(alpha,bestScore);
                    if (alpha >= beta){break;}
                }
            }
//            }
        }else if (sense == -1){
//            if (board.moveLegal(Move.pass())){
//                allPossibleMoves.add(Move.pass());
//            }else{
            bestScore = INFTY;
            allPossibleMoves = possibleMoves(board, BLUE);
            for (Move possible : allPossibleMoves){
                Board copy = new Board(board);
                copy.createMove(possible);
                int response = minMax(copy, depth - 1, false,1,alpha,beta);
                if (response < bestScore){
                    bestMove = possible;
                    bestScore = response;
                    alpha = min(beta,bestScore);
                    if (alpha >= beta){break;}
                }
//                }
            }
        }
        if (save){
            lastFoundMove = bestMove;
        }
        return bestScore;
    }


    /** @param  board: A new board for ataxx
     *          winningValue: Winning weigth
     *  @return A winning weight value () for BOARD.  This value is + or - WINNINGVALUE in
     *           won positions, and 0 for ties.*/
    private int staticScore(Board board, int winningValue) {
        PieceState winner = board.getWinner();
        if (winner != null) {
            return switch (winner) {
                case RED -> winningValue;
                case BLUE -> -winningValue;
                default -> 0;
            };
        }
        if (board.nextMove() == RED ) {
            return board.getColorNums(RED) - board.getColorNums(BLUE);
        } else {
            return board.getColorNums(BLUE) - board.getColorNums(RED);
        }
    }


    /** Reset the countred and countblue to 0 so that AIPlayer's depth is reset to 4*/
    public void Reset(){
        countred = 0;
        countblue = 0;
    }

    /** Return a move for me from the current position, assuming there
     *  is a move. */
    private Move findMove() {
        Board b = new Board(getAtaxxBoard());
        lastFoundMove = null;


        // Here we just have the simple AI to randomly move.
        // However, it does not meet with the requirements of Part A.2.
        // Therefore, the following codes should be modified
        // in order to meet with the requirements of Part A.2.
        // You can create add your own method and put your method here.

//        ArrayList<Move> listOfMoves =
//                possibleMoves(b, b.nextMove());
//        int moveArrayLength = listOfMoves.size();
//        int randomIndex = (int) (Math.random() * moveArrayLength);
//        for(int i = 0; i < moveArrayLength; i++){
//            if (i == randomIndex){
//                b.createMove(listOfMoves.get(i));
//                lastFoundMove = listOfMoves.get(i);
//            }
//        }
        if (getMyState() == RED){

            if(countred < 4){
                minMax(b, MAX_DEPTH-1, true, 1, -INFTY,INFTY);
                countred+=2;

            }else {
                minMax(b, MAX_DEPTH-1, true, 1, -INFTY,INFTY);
            }
        }else{

            if(countblue < 4){
                minMax(b, MAX_DEPTH-1, true, -1, -INFTY,INFTY);
                countblue+=2;

            }else {
                minMax(b, MAX_DEPTH-1, true, -1, -INFTY,INFTY);
            }

        }


        // Please do not change the codes below
        if (lastFoundMove == null) {
            lastFoundMove = Move.pass();
        }
        return lastFoundMove;
    }


    /** The move found by the last call to the findMove method above. */
    private Move lastFoundMove;

    int countred = 0; //count the first two steps of RED
    int countblue = 0; //count the first two steps of BLUE
    public int getcountred(){return countred;}


    /** Return all possible moves for a color.
     * @param board the current board.
     * @param myColor the specified color.
     * @return an ArrayList of all possible moves for the specified color. */
    private ArrayList<Move> possibleMoves(Board board, PieceState myColor) {
        ArrayList<Move> possibleMoves = new ArrayList<>();
        for (char row = '7'; row >= '1'; row--) {
            for (char col = 'a'; col <= 'g'; col++) {
                int index = Board.index(col, row);
                if (board.getContent(index) == myColor) {
                    ArrayList<Move> addMoves
                            = assistPossibleMoves(board, row, col);
                    possibleMoves.addAll(addMoves);
                }
            }
        }
        return possibleMoves;
    }

    /** Returns an Arraylist of legal moves.
     * @param board the board for testing
     * @param row the row coordinate of the center
     * @param col the col coordinate of the center */
    private ArrayList<Move>
    assistPossibleMoves(Board board, char row, char col) {
        ArrayList<Move> assistPossibleMoves = new ArrayList<>();
        for (int i = -2; i <= 2; i++) {
            for (int j = -2; j <= 2; j++) {
                if (i != 0 || j != 0) {
                    char row2 = (char) (row + j);
                    char col2 = (char) (col + i);
                    Move currMove = Move.move(col, row, col2, row2);
                    if (board.moveLegal(currMove)) {
                        assistPossibleMoves.add(currMove);
                    }
                }
            }
        }
        return assistPossibleMoves;
    }
}
