import org.junit.Assert;
import org.junit.Test;

public class DelDuplicateTest {
	@Test
    public void delduplicatetest(){
        String input="aaabbc";
        Assert.assertEquals("abc",DelDuplicate.delDuplicate(input));
    }


    @Test
    public void Singleletterdelduplicatetest(){
        String input="aaaaaa";
        Assert.assertEquals("a",DelDuplicate.delDuplicate(input));
    }

    @Test
    public void Doubleletterdelduplicatetest(){
        String input="";
        Assert.assertEquals("",DelDuplicate.delDuplicate(input));
    }
}
