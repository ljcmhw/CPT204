import java.util.Scanner;

public class addsum {


    public static void main(String[] args) {
        int sum = 0;
        int count = 0;
        Scanner input = new Scanner(System.in);
        int n = input.nextInt();
        String a = input.next().toString();
        if(n==0){
            sum=3;
        }
        String[] str1 = a.split(" ");
//        String str1[] = new String[n];
//        for(int i=0;i<str1.length;i++){
//            str1[i] = input.next();
//            }

        String str2[] = new String[n];
        for(int k=0;k<str2.length;k++){
            str2[k] = input.next();
        }
        for(int j = 0;j<str1.length;j++){
            if(str1[j].equals(str2[j])){
                sum+=3;
            }else {
                if(str2[j].contains(str1[j])){
                    sum+=1;

                }
            }
        }
        System.out.println(sum);
//        Scanner input = new Scanner(System.in);
//        int n = input.nextInt();
//        int k = input.nextInt();
//        int l[] = new int[n];
//        for(int i=0;i<n;i++){
//            l[i] = input.nextInt();
//        }
//        System.out.println(l);
    }

}

