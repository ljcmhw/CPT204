import org.junit.Assert;
import org.junit.Test;

import java.util.Arrays;
import java.util.List;

public class SkipSumTest {
    @Test
    public void skipsumtesttrue(){
        List<Integer> list = Arrays.asList(2,5,6,11);
        Assert.assertEquals(true,SkipSum.skipSum(list,0));
    }

    @Test
    public void skipsumtestfalse(){
        List<Integer> list = Arrays.asList(2,5,10,6);
        Assert.assertEquals(false,SkipSum.skipSum(list,16));
    }
    @Test
    public void singletest(){
        List<Integer> list = Arrays.asList(2,5,10,6);
        Assert.assertEquals(true,SkipSum.skipSum(list,2));
    }
}
