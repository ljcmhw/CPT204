import org.junit.Assert;
import org.junit.Test;

public class CountBabaMamaTest {
	@Test
    public void countbabamamatest(){
        String input="aba babaa amama ma";
        Assert.assertEquals(2,CountBabaMama.countBabaMama(input));
    }

    @Test
    public void overlaptest(){
        String input="bababamamama";
        Assert.assertEquals(4,CountBabaMama.countBabaMama(input));
    }
	
}
