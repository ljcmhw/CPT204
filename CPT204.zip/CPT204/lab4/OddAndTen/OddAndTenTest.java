import org.junit.Assert;
import org.junit.Test;

import java.util.Arrays;
import java.util.List;

public class OddAndTenTest {
    @Test
    public void truecase(){
        List<Integer>list = Arrays.asList(5,5,3);
        Assert.assertEquals(true,OddAndTen.oddAndTen(list));
    }

    @Test
    public void falsecase(){
        List<Integer>list = Arrays.asList(5,5,4);
        Assert.assertEquals(false,OddAndTen.oddAndTen(list));
    }

    @Test
    public void nullcase(){
        List<Integer>list = Arrays.asList(3);
        Assert.assertEquals(true,OddAndTen.oddAndTen(list));
    }
}
