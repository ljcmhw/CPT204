import org.junit.Test;
import static org.junit.Assert.*;
public class LeapYearTest {

    @Test
    public void LeapYeartest(){
        int year = 1600;
        assertTrue(LeapYear.isLeapYear(year));
    }
	
    
}