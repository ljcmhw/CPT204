import org.junit.Test;
import static org.junit.Assert.*;

public class AppearOnceTest {

    @Test
    public void testAppearOnce1() {
        char expectedCharacter = 'b';
        assertEquals(expectedCharacter, AppearOnce.appearOnce("abca"));
    }

    @Test
    public void testAppearOnce2() {
        assertEquals('\n', AppearOnce.appearOnce("abccba"));
    }

    // add more test cases yourself ...



}