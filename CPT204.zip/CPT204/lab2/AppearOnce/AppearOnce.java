public class AppearOnce {

    /**
	 * Returns the first character that appears exactly once in the string.
	 * For example, appearOnce("abca") -> 'b'.
	 * @param input a non-empty string.
	 * @return the first character that appears exactly once.
	 * @return the new line character if there is no character that appears exactly once.
	 */
	 public static char appearOnce(String input) {
		char result = input.charAt(0);
		int count1=0;
		for (int count=0; count<input.length();count++){
			if(result==input.charAt(count)&&count!=count1&&count1<input.length()){
				count1++;
				if(count1==input.length()){
					result='\n';
					break;
				}
				else{result=input.charAt(count1);
				count=-1;}
			}


			}

    
		return result;
	}

}