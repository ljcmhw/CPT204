public class ConcatContain {

    /**
     * Compute the smallest number of times source is concatenated with itself
     * so that the resulting string contains target.
     * For example, For example, source "ab" concatenated 2 times "ab"+"ab"+"ab" into "ababab"
     * contains target "baba".
     * @param source a non-empty string to be concatenated.
     * @param target a non-empty string that can be contained in repeatedly concatenated source.
     * @return the smallest number of times of the concatenation.
     */
    public static int concatContain(String source, String target) {

        int numberofrepeat=0;
        String concatsource=source;
        while (concatsource.contains(target) == false) {
            if (concatsource.length() <= (target.length() * 1.5)) {
                numberofrepeat++;
                concatsource += source;
                if(concatsource.contains(target)==true){
                    break;
                }
            }
            if (concatsource.length() > (target.length() * 1.5)) {
                numberofrepeat = -1;
                break;
            }
        }
		
		return numberofrepeat;
    }

    
}