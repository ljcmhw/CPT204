public class LLDeque<T> {

    private class Node {
        Node prev;
        T item;
        Node next;

        Node(Node p, T i, Node n) {
            prev = p;
            item = i;
            next = n;
        }
    }

    private Node sentinel;
    private int size;

    /**
     * @return the number of items in the deque.
     */
    public int size() {
        return size;
    }

    /**
     * @return true if deque is empty, false otherwise.
     */
    public boolean isEmpty() {
        return size == 0;
    }

    /*
     ***************************
     * DO NOT MODIFY CODE ABOVE
     ***************************
     */


    // LAB EXERCISE #6.1 EMPTY CONSTRUCTOR

    /**
     * Creates an empty deque.
     */
    public LLDeque() {
		sentinel = new Node(null,null,null);
        sentinel.next = sentinel;
        sentinel.prev = sentinel;
        size = 0;
		
		
    }


    // LAB EXERCISE #6.2 ADD TO FRONT

    /**
     * Adds an item of type T to the front of the deque.
     * @param item is a type T object added to the deque.
     */
    public void addFirst(T item) {
		Node input = new Node(sentinel,item,sentinel.next);
        sentinel.next.prev=input;
        sentinel.next=input;
		size++;
		
    }


    // LAB EXERCISE #6.3 PRINT ITEMS

    /**
     * Prints the items in the deque from first to last,
     * separated by a space, ended with a new line.
     */
    public void printDeque() {
		Node p = sentinel.next;

        if(p.next==sentinel){
            System.out.print(p.item);
            System.out.println();
        }
        else {
            while (p.next != sentinel) {
                System.out.print(p.item + " ");
                p = p.next;

            }
            System.out.print(p.item+" ");
            System.out.println();
        }

    }


    // LAB EXERCISE #6.4 ITERATIVE GET ITEM

    /**
     * Gets the item at the given index.
     * If no such item exists, returns null.
     * Does not mutate the deque.
     * @param index is an index where 0 is the front.
     * @return the ith item of the deque, null if it does not exist.
     */
    public T iterGet(int index) {
        Node p = sentinel.next;
		if(p==sentinel||index<0||index>=size){
            return null;
        }else {
            for (int i=0;i<index;i++){
                p = p.next;
            }
            return p.item;
        }
		

    }


    // CODING ASSIGNMENT #6.1 ADD TO BACK

    /**
     * Adds an item of type T to the back of the deque.
     * @param item is a type T object added to the deque.
     */
    public void addLast(T item) {
		Node input = new Node(sentinel.prev,item,sentinel);
        sentinel.prev.next = input;
        sentinel.prev = input;
        size++;
		
		
    }


    // CODING ASSIGNMENT #6.2 DELETE FRONT

    /**
     * Deletes and returns the item at the front of the deque.
     * If no such item exists, returns null.
     * @return the first item of the deque, null if it does not exist.
     */
    public T delFirst() {

        if(size==0){
            return null;
        }else {
            T output = sentinel.next.item;
            sentinel.next.next.prev=sentinel;
            sentinel.next=sentinel.next.next;
            size--;
            return output;

        }
		

    }


    // CODING ASSIGNMENT #6.3 DELETE BACK

    /**
     * Deletes and returns the item at the back  of the deque.
     * If no such item exists, returns null.
     * @return the last item of the deque, null if it does not exist.
     */
    public T delLast() {
		if(size==0){
            return null;
        }else {
            T output = sentinel.prev.item;
            sentinel.prev.prev.next=sentinel;
            sentinel.prev = sentinel.prev.prev;

            size--;
            return output;
        }
		

    }


    // CODING ASSIGNMENT #6.4 RECURSIVE GET ITEM

    /**
     * Gets the item at the given index.
     * If no such item exists, returns null.
     * Does not mutate the deque.
     * @param index is an index where 0 is the front.
     * @return the ith item of the deque, null if it does not exist.
     */
    public T recGet(int index) {
		if(index<0||index>=size){
            return null;
        }
        if(index==0){
            return sentinel.next.item;
        }
        Node sentinel2 = sentinel;
//            sentinel.next.next.prev=sentinel;
//            sentinel.next=sentinel.next.next;
//            size--;
            sentinel = sentinel.next;

//            Node sentinel1 = new Node(null,null,null);
//
//            sentinel1.prev = sentinel.next;
//            sentinel1.next = sentinel.next.next;
//            sentinel.next.next.prev=sentinel1;
//            sentinel.next.next=sentinel1;
//
//            sentinel.prev.next=sentinel.next;
//            sentinel.next.prev=sentinel.prev;
//            sentinel = sentinel1;
//            sentinel.prev=sentinel.;
//            sentinel.prev=sentinel.next;
//            sentinel.next.next=sentinel;
//            sentinel.next.next.prev=sentinel;
            index--;
            T output = recGet(index);
            sentinel = sentinel2;




        return output;
    }   
	

    public static void main(String[] args) {
        LLDeque<String> deque = new LLDeque<>();
        deque.addLast("b");
        deque.addLast("a");
        deque.addLast("easy");
//        String delete = deque.delLast();
        String result = deque.recGet(2);
//        deque.iterGet(1);
//        System.out.println(delete);
        deque.printDeque();
        System.out.println(result);
    }

}
