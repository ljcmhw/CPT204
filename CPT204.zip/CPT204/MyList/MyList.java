public class MyList {
    private int value;
    private MyList next;

    public MyList(int value, MyList next) {
        this.value = value;
        this.next = next;
    }

    // LAB EXERCISE #5.1 MYLIST ITERATIVE SQUARE MUTATE 

    /**
     * Square the elements of a MyList. Mutates the MyList.
     * @param list is a MyList object.
     */
    public static void iterSquareMutList(MyList list) {
        MyList p = list;
        while(p!=null){
            p.value*=p.value;
            p=p.next;
        }


    }


    // LAB EXERCISE #5.2 MYLIST RECURSIVE SQUARE MUTATE 

    /**
     * Square the elements of a MyList. Mutates the MyList.
     * @param list is a MyList object.
     */
    public static void recSquareMutList(MyList list) {

        // base case
        if(list==null){

        } else if(list.next==null){
            list.value*=list.value;
        }

        // recursive step
        else {list.value*=list.value;
        recSquareMutList(list.next);}


    }


    // LAB EXERCISE #5.3 MYLIST ITERATIVE SQUARE IMMUTATE 

    /**
     * Square the elements of a MyList. Does not mutate the MyList.
     * @param list is a MyList object.
     * @return another MyList with all of input MyList's element squared.
     */
    public static MyList iterSquareList(MyList list) {
        if(list==null){
            return null;
        }
        MyList list2 = new MyList(list.value*list.value,null);
        MyList p = list2;
        while(list.next!=null){
            list=list.next;
            p.next = new MyList(list.value* list.value,null);
            p = p.next;
        }


        return list2;
    }


    // LAB EXERCISE #5.4 MYLIST RECURSIVE SQUARE IMMUTATE 

    /**
     * Square the elements of a MyList. Does not mutate the MyList.
     * @param list is a MyList object.
     * @return another MyList with all of input MyList's element squared.
     */
    public static MyList recSquareList(MyList list) {


        // base case
        if(list==null){
            return null;
        }

        // recursive step

        MyList list2 = new MyList(list.value*list.value,recSquareList(list.next));
        return list2;


    }


    // CODING ASSIGNMENT #5.1 MYLIST ITERATIVE CATENATE MUTATE 

    /**
     * Catenate two MyLists, listA and listB. Mutate listA.
     * @param listA is a MyList object.
     * @param listB is a MyList object.
     * @return a list consisting of the elements of listA followed by the
     * elements of listB.
     */
    public static MyList iterCatMutList(MyList listA, MyList listB) {
        if(listA==null){
            if(listB==null){
                return null;
            }else return listB;
        }
        MyList p = listA;
        while (p.next!=null){
            p = p.next;

        }
        p.next=listB;
//        if(listB!=null){
//
//            p = new MyList(listB.value,null);
//            while (listB.next!=null){
//                listB=listB.next;
//                p = new MyList(listB.value,null);
//                p = p.next;
//
//            }
//        }


        return listA;
    }


    // CODING ASSIGNMENT #5.2 MYLIST RECURSIVE CATENATE MUTATE 

    /**
     * Catenate two MyLists, listA and listB. Mutate listA.
     * @param listA is a MyList object.
     * @param listB is a MyList object.
     * @return a list consisting of the elements of listA followed by the
     * elements of listB.
     */
    public static MyList recCatMutList(MyList listA, MyList listB) {

        // base case
        if(listA!=null){
        if(listA.next==null){
            if(listB==null){
                return listA;
            }else {listA.next=listB;
                    return listA;
            }
        }}else {
            if (listB == null) {
                return null;
            } else{
                return listB;
            }
        }

        // recursive step
        listA = new MyList(listA.value,recCatMutList(listA.next,listB));
        return listA;
    }


    // CODING ASSIGNMENT #5.3 MYLIST ITERATIVE CATENATE IMMUTATE 

    /**
     * Catenate two MyLists, listA and listB. Does not mutate listA.
     * @param listA is a MyList object.
     * @param listB is a MyList object.
     * @return a list consisting of the elements of listA followed by the
     * elements of listB.
     */
    public static MyList iterCatList(MyList listA, MyList listB) {
        if(listA==null){
            if(listB==null){
                return null;
            }else return listB;
        }
        MyList list = new MyList(listA.value,null);
        MyList p1 = list;
        while (listA.next!=null){
            listA = listA.next;
            p1.next =new MyList(listA.value,null);
            p1 = p1.next;
        }
        MyList p = list;
        while (p.next!=null){
            p = p.next;

        }
        p.next=listB;


        return list;
    }


    // CODING ASSIGNMENT #5.4 MYLIST RECURSIVE CATENATE IMMUTATE 

    /**
     * Catenate two MyLists, listA and listB. Does not mutate listA.
     * @param listA is a MyList object.
     * @param listB is a MyList object.
     * @return a list consisting of the elements of listA followed by the
     * elements of listB.
     */
    public static MyList recCatList(MyList listA, MyList listB) {

        // base case
        if(listA==null){
            if(listB==null){
                return null;
            }else {
                return listB;
            }
        }


        // recursive step
        MyList list = new MyList(listA.value,recCatList(listA.next,listB));
        return list;


    }





    /*
     *
     *****  Do NOT modify the codes below from the lecture notes!  *****
     *****  Only for your JUnit Testing purposes!                  *****
     *
     */


    /**
     * @return the size of the MyList iteratively.
     */
    public int iterSize() {
        MyList p = this;
        int size = 0;
        while (p != null) {
            size += 1;
            p = p.next;
        }
        return size;
    }

    /**
     * @return the size of the MyList recursively.
     */
    public int recSize() {
        // base case
        if (next == null) {
            return 1;
        }
        // recursive step
        return 1 + this.next.recSize();
    }

    /**
     * @param i is a valid index of MyList.
     * @return the ith value of this MyList.
     */
    public int get(int i) {
        // base case
        if (i == 0) {
            return value;
        }
        // recursive step
        return next.get(i - 1);
    }

    /**
     * @param args is a variable number of integers.
     * @return a new MyList containing the integers in args.
     */
    public static MyList ofEntries(Integer... args) {
        MyList result, p;
        if (args.length > 0) {
            result = new MyList(args[0], null);
        } else {
            return null;
        }
        int k;
        for (k = 1, p = result; k < args.length; k += 1, p = p.next) {
            p.next = new MyList(args[k], null);
        }
        return result;
    }

    /**
     * @param l is a MyList object.
     * @return true iff l is a MyList object containing the same sequence of
     * integers as this.
     */
    public boolean equals(Object l) {
        if (!(l instanceof MyList)) {
            return false;
        }
        MyList list = (MyList) l;
        MyList p;
        for (p = this; p != null && list != null; p = p.next, list = list.next) {
            if (p.value != list.value) {
                return false;
            }
        }
        if (p != null || list != null) {
            return false;
        }
        return true;
    }

    public String toString() {
        int size = this.recSize();
        String output= "[";
        for (int i = 0; i < size; i++) {
            output = output + this.get(i);
            if (i != size-1)
                output = output + ", ";
        }
        output = output + "]";
        return output;
    }

    public static MyList combinesMyList(MyList list) {
        MyList result1 = new MyList(list.get(0), null);
        MyList p = list;
        MyList point = result1;
        int count = 0;
        while (p!=null) {
            while (p.next != null) {
        if (p.value == p.next.value) {
            p.next.value += p.value;
            p = p.next;
//                count++;
        } else break;
    }
        point.value = p.value;
            if(p.next!=null){
        point.next = new MyList(0, null);}
        point = point.next;
        p = p.next;
}

//            point = point.next;
//            for(;count>=0;count--){
//                p=p.next;
//            }
//            count = 0;


        return result1;
    }


    public static void main(String[] args){
        MyList list1 = MyList.ofEntries(0, 1);
        MyList list2 = MyList.ofEntries(4, 5, 6);

        System.out.println(MyList.recCatList(list1, list2));
        System.out.println(list1);
    }

}
