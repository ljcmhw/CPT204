import java.util.Iterator;

public class ARDeque<T> implements Deque<T>, Iterable<T> {
    private T[] items;
    private int size;
    private int nextFirst;
    private int nextLast;

    /**
     * @return the size of the array used in the deque.
     */
    public int itemsLength() {
        return items.length;
    }

    /**
     * @return the number of items in the deque.
     */
    @Override
    public int size() {
        return size;
    }

    /**
     * @return true if deque is empty, false otherwise.
     */
    public boolean isEmpty() {
        return size == 0;
    }


    /*
     ***************************
     * DO NOT MODIFY CODE ABOVE
     ***************************
     */


    /*
     ***** HELPER METHODS START *****
     */

    // add your own helper methods here
    private int plusOne(int index){
        return (index+1) % itemsLength();
    }

    private int minusOne(int index){
        if(index==0){
            index = itemsLength()-1;
        }else {
            index--;
        }
        return index;
    }

    @SuppressWarnings("unchecked")
    private void resize(int capacity) {
        T[] newArray = (T[]) new Object[capacity];
        int curr = plusOne(nextFirst); // the first item of the deque
        for(int i=0;i<size;i++){
            newArray[i] = items[curr];
            curr = plusOne(curr);
        }
        items = newArray;
        nextFirst = capacity-1;
        nextLast = size;
    }



    // INCLUDE in your submission
    // if you use them in your method

    /*
     ***** HELPER METHODS END *****
     */


    // add your own ARDeque codes from previous labs
    @SuppressWarnings("unchecked")
    public ARDeque() {
        items = (T[]) new Object[4];
        nextFirst = 1;
        nextLast = 2;
        size = 0;


    }

    public void addLast(T item) {

        if(size==itemsLength()){
            resize(2*size);

        }

        items[nextLast] = item;
        size++;
        nextLast = plusOne(nextLast);


    }
    public void printDeque() {
        int index = plusOne(nextFirst);
        for(int i=0;i<size;i++){
            System.out.print(items[index]+" ");
            index = plusOne(index);
        }
        System.out.println();

    }
    public T get(int index) {
        if(size==0||index<0||index>=size){
            throw new ArrayIndexOutOfBoundsException("Index " +index + " is not valid");

        }
        int target = (plusOne(nextFirst) + index)%itemsLength();
        return items[target];
    }
    public void addFirst(T item) {
        if(size==itemsLength()){
            resize(2*size);
        }

        items[nextFirst] = item;
        size++;
        nextFirst = minusOne(nextFirst);



    }
    public T delFirst() {

        int start = plusOne(nextFirst);
        int end = minusOne(nextLast);
        T x = null;
        if(((nextFirst+1)%itemsLength())==nextLast){

        }else {
            x = items[start];
            nextFirst = plusOne(nextFirst);
            size--;

            if(size<=(itemsLength()/4)&&size>=0){
                resize(itemsLength()/2);
            }

        }

        return x;
    }

    public T delLast(){
        int start = plusOne(nextFirst);
        int end = minusOne(nextLast);
        T x = null;
        if(((nextFirst+1)%itemsLength())==nextLast){

        }else {
            x = items[end];
            nextLast = minusOne(nextLast);
            size--;

            if(size<=(itemsLength()/4)&&size>=0){
                resize(itemsLength()/2);
            }

        }

        return x;
    }


    // CODING ASSIGNMENT #11.3  ITERATOR

    /**
     * Make an iterator
     */
    @Override
    public Iterator<T> iterator() {
        return new ARDequeIterator();


    }

    private class ARDequeIterator implements Iterator<T> {
        private int index;
        public ARDequeIterator(){index = plusOne(nextFirst);}

        @Override
        public boolean hasNext(){return index!=nextLast;}

        @Override
        public T next(){
            T nextItem = items[index];
            index = plusOne(index);
            return nextItem;
        }


    }

}