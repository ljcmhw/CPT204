import org.junit.Test;

public class ARDequeTest {
    @Test
    public void testiter(){
        ARDeque<String> deque = new ARDeque<>();
        deque.addLast("a");
        deque.addLast("b");
        deque.addLast("c");
        for (String item : deque) { System.out.print(item + " ");
        }
    }
}
