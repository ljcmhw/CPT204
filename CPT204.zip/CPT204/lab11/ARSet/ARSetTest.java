import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.*;

public class ARSetTest {

    @Test
    public void testSet_1() {
        ARSet<String> set = new ARSet<>();
        List<String> list1 = new ArrayList<>();
        list1.add("b");
        List<String> list2 = new ArrayList<>();
        list2.add("c");
        set.add(null);
        set.add(list1.get(0));
        assertEquals(false, set.contains(null));
        assertEquals(2, set.size());
        for (String item : set) {
            System.out.println(item);
        }
    }
	
	// add your own test cases here:
	
	
	
	
	
}
